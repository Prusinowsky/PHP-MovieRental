<?php
    
// Załaduj główny plik ładujący
require_once '../Bootstrap.php';