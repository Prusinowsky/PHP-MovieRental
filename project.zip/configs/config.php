<?php 

    /**
     * Plik zawiera wszystkie dane potrzebne do połączenia się z bazą danych MySQL
     */

    return [
        'database' => [
            'host'      => 'localhost',
            'database'  => 'movie-rental',
            'username'  => 'root',
            'password'  => '',
            'port' => '',
            'encoding' => '',
        ]
    ];